package org.employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

@Service
public class CustomerService {

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    private static final String PREFIX = "Customer::";

    public Customer getCustomerById(String customerId) {
        String key = PREFIX + customerId;

        // Check in Redis cache first
        Customer cachedCustomer = (Customer) redisTemplate.opsForValue().get(key);
        if (cachedCustomer != null) {
            System.out.println("Returned from Redis Cache");
            return cachedCustomer;
        }

        // Simulate DB fetch
        Customer customer = new Customer(customerId, "John Doe", "Savings");

        // Cache the result in Redis
        redisTemplate.opsForValue().set(key, customer, 10, TimeUnit.MINUTES);
        return customer;
    }

    public void evictCache(String customerId) {
        redisTemplate.delete(PREFIX + customerId);
    }
}
