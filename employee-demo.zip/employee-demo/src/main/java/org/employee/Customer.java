package org.employee;

import java.io.Serializable;

public class Customer implements Serializable {
    private String id;
    private String name;
    private String accountType;

    
    public Customer() {}
    
    public Customer(String id, String name, String accountType) {
        this.id = id;
        this.name = name;
        this.accountType = accountType;
    }

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

    
}
