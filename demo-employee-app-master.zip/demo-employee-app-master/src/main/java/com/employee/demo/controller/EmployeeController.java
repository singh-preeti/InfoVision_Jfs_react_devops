package com.employee.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.demo.model.Employee;
import com.employee.demo.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/add")
	public ResponseEntity<Employee> addAll(@RequestBody Employee emp){
		return ResponseEntity.ok(employeeService.save(emp));
	}
	@GetMapping("/get")
	public ResponseEntity<List<Employee>> getAll(){
		return ResponseEntity.ok(employeeService.findAll());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Employee> getAllById(@PathVariable Long id){
		return ResponseEntity.ok(employeeService.findById(id).orElse(null));
	}
	@PutMapping("/update")
	public ResponseEntity<Employee> updateAll(@RequestBody Employee emp){
		return ResponseEntity.ok(employeeService.save(emp));
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<Employee> delete(@PathVariable Long id) {
		employeeService.findById(id).ifPresent(employeeService::delete);
		return ResponseEntity.ok().build();
	}

}
